from __future__ import annotations
import logging as logging
import sys as sys
from .rdBase import *
__all__: list[str] = ['VECT_WRAPS', 'VectIter', 'log_handler', 'logger', 'logging', 'name', 'object', 'rdBase', 'sys']
class VectIter:
    def __init__(self, vect):
        ...
    def __iter__(self):
        ...
    def __next__(self):
        ...
def __vect__iter__(vect):
    ...
VECT_WRAPS: set = {'UnsignedLong_Vect', 'MatchTypeVect', 'VectSizeT', 'VectorOfStringVectors'}
__version__: str = '2026.09.1'
log_handler: logging.StreamHandler
logger: logging.Logger
name: str = '__file__'
object: str = '/project/build/temp.linux-x86_64-cpython-313/rdkit_install/lib/python3.13/site-packages/rdkit/rdBase.so'
