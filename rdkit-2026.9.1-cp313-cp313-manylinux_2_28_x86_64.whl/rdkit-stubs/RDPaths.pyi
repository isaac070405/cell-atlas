from __future__ import annotations
import os as os
__all__: list[str] = ['RDCodeDir', 'RDContribDir', 'RDDataDir', 'RDDocsDir', 'RDProjDir', 'os']
RDCodeDir: str = '/project/build/temp.linux-x86_64-cpython-313/rdkit_install/lib/python3.13/site-packages/rdkit'
RDContribDir: str = '/project/build/temp.linux-x86_64-cpython-313/rdkit_install/share/RDKit/Contrib'
RDDataDir: str = '/project/build/temp.linux-x86_64-cpython-313/rdkit_install/share/RDKit/Data'
RDDocsDir: str = '/project/build/temp.linux-x86_64-cpython-313/rdkit_install/share/RDKit/Docs'
RDProjDir: str = '/project/build/temp.linux-x86_64-cpython-313/rdkit_install/share/RDKit/Projects'
_share: str = '/project/build/temp.linux-x86_64-cpython-313/rdkit_install/share/RDKit'
