"""
Module containing classes and functions for enumerating molecules
"""
from __future__ import annotations
import rdkit.Chem
import typing
__all__: list[str] = ['Enumerate', 'EnumeratorType', 'MolEnumeratorParams']
class EnumeratorType(Boost.Python.enum):
    LinkNode: typing.ClassVar[EnumeratorType]
    PositionVariation: typing.ClassVar[EnumeratorType]
    RepeatUnit: typing.ClassVar[EnumeratorType]
    __slots__: typing.ClassVar[tuple] = tuple()
    names: typing.ClassVar[dict]
    values: typing.ClassVar[dict]
class MolEnumeratorParams(Boost.Python.instance):
    """
    Molecular enumerator parameters
    """
    __instance_size__: typing.ClassVar[int] = 64
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    @staticmethod
    def __setattr__(arg1: typing.Any, arg2: str, arg3: typing.Any) -> None:
        """
            C++ signature :
                void __setattr__(boost::python::api::object,std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >,boost::python::api::object)
        """
    def SetEnumerationOperator(self, typ: EnumeratorType) -> None:
        """
            set the operator to be used for enumeration
        
            C++ signature :
                void SetEnumerationOperator(RDKit::MolEnumerator::MolEnumeratorParams*,(anonymous namespace)::EnumeratorTypes)
        """
    @typing.overload
    def __init__(self) -> None:
        """
            C++ signature :
                void __init__(_object*)
        """
    @typing.overload
    def __init__(self, arg1: EnumeratorType) -> typing.Any:
        """
            C++ signature :
                void* __init__(boost::python::api::object,(anonymous namespace)::EnumeratorTypes)
        """
    @property
    def doRandom(*args, **kwargs):
        """
        do random enumeration (not yet implemented
        """
    @doRandom.setter
    def doRandom(*args, **kwargs):
        ...
    @property
    def maxToEnumerate(*args, **kwargs):
        """
        maximum number of molecules to enumerate
        """
    @maxToEnumerate.setter
    def maxToEnumerate(*args, **kwargs):
        ...
    @property
    def randomSeed(*args, **kwargs):
        """
        seed for the random enumeration (not yet implemented
        """
    @randomSeed.setter
    def randomSeed(*args, **kwargs):
        ...
    @property
    def sanitize(*args, **kwargs):
        """
        sanitize molecules after enumeration
        """
    @sanitize.setter
    def sanitize(*args, **kwargs):
        ...
@typing.overload
def Enumerate(mol: Mol, maxPerOperation: int = 0) -> rdkit.Chem.MolBundle:
    """
        do an enumeration and return a MolBundle.
          If maxPerOperation is >0 that will be used as the maximum number of molecules which 
            can be returned by any given operation.
        Limitations:
          - the current implementation does not support molecules which include both
            SRUs and LINKNODEs
          - Overlapping SRUs, i.e. where one monomer is contained within another, are
            not supported
    
        C++ signature :
            RDKit::MolBundle* Enumerate(RDKit::ROMol [,unsigned int=0])
    """
@typing.overload
def Enumerate(mol: Mol, enumParams: MolEnumeratorParams) -> rdkit.Chem.MolBundle:
    """
        do an enumeration for the supplied parameter type and return a MolBundle
        Limitations:
          - Overlapping SRUs, i.e. where one monomer is contained within another, are
            not supported
    
        C++ signature :
            RDKit::MolBundle* Enumerate(RDKit::ROMol,RDKit::MolEnumerator::MolEnumeratorParams)
    """
