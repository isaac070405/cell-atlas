"""
Module containing classes and functions for working with ChemDraw files.
"""
from __future__ import annotations
import typing
__all__: list[str] = ['CDXFormat', 'MolToChemDrawBlock', 'MolsFromChemDrawBlock', 'MolsFromChemDrawFile', 'NeedsCleanPolicy', 'ReactionsFromChemDrawBlock', 'ReactionsFromChemDrawFile']
class CDXFormat(Boost.Python.enum):
    CDX: typing.ClassVar[CDXFormat]
    CDXML: typing.ClassVar[CDXFormat]
    __slots__: typing.ClassVar[tuple] = tuple()
    names: typing.ClassVar[dict]
    values: typing.ClassVar[dict]
class NeedsCleanPolicy(Boost.Python.enum):
    TrustExplicitHydrogens: typing.ClassVar[NeedsCleanPolicy]
    TrustSource: typing.ClassVar[NeedsCleanPolicy]
    __slots__: typing.ClassVar[tuple] = tuple()
    names: typing.ClassVar[dict]
    values: typing.ClassVar[dict]
def MolToChemDrawBlock(mol: Mol, format: CDXFormat = ...) -> str:
    """
        Convert a molecule into a chemdraw string using the specified format
        
             ARGUMENTS:
        
               - mol: the molecule to convert
        
               - format: The ChemDraw format to use, CDXML/CDX [default CDXML]
        
             RETURNS:
               an iterator of parsed ChemicalReaction objects.
    
        C++ signature :
            std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > MolToChemDrawBlock(RDKit::ROMol [,RDKit::v2::CDXFormat=rdkit.Chem.rdChemDraw.CDXFormat.CDXML])
    """
def MolsFromChemDrawBlock(block: str, sanitize: bool = True, removeHs: bool = True, needsCleanPolicy: NeedsCleanPolicy = ..., parseQueries: bool = False, strictQueryParsing: bool = False) -> typing.Any:
    """
        Extract all molecules from a ChemDraw file.
        
             Note that the ChemDraw format is large and complex, the RDKit doesn't support
             full functionality, just the base ones required for molecule and
             reaction parsing.
        
             ARGUMENTS:
        
               - block: the CDX/CDXML block
        
               - sanitize: if True, sanitize the molecules [default True]
        
               - removeHs: if True, convert explicit Hs into implicit Hs. [default True]
        
               - needsCleanPolicy: how to handle `NeedsClean` hydrogen metadata.
                `TrustSource` honors `NeedsClean` by allowing sanitization to
                recompute hydrogens. `TrustExplicitHydrogens` preserves the literal
                source metadata when sanitize is True. [default TrustSource]
        
             RETURNS:
               a tuple of parsed Mol objects.
    
        C++ signature :
            boost::python::api::object MolsFromChemDrawBlock(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > [,bool=True [,bool=True [,RDKit::v2::NeedsCleanPolicy=rdkit.Chem.rdChemDraw.NeedsCleanPolicy.TrustSource [,bool=False [,bool=False]]]]])
    """
def MolsFromChemDrawFile(filename: typing.Any, sanitize: bool = True, removeHs: bool = True, needsCleanPolicy: NeedsCleanPolicy = ..., parseQueries: bool = False, strictQueryParsing: bool = False) -> tuple:
    """
        Extract all molecules from a ChemDraw file.
        
             Note that the ChemDraw format is large and complex, the RDKit doesn't support
             full functionality, just the base ones required for molecule and
             reaction parsing.
        
             ARGUMENTS:
        
               - filename: the chemdraw filename (.cdx/.cdxml)
        
               - sanitize: if True, sanitize the molecules [default True]
        
               - removeHs: if True, convert explicit Hs into implicit Hs. [default True]
        
               - needsCleanPolicy: how to handle `NeedsClean` hydrogen metadata.
                `TrustSource` honors `NeedsClean` by allowing sanitization to
                recompute hydrogens. `TrustExplicitHydrogens` preserves the literal
                source metadata when sanitize is True. [default TrustSource]
        
             RETURNS:
               a tuple of parsed Mol objects.
    
        C++ signature :
            boost::python::tuple MolsFromChemDrawFile(boost::python::api::object [,bool=True [,bool=True [,RDKit::v2::NeedsCleanPolicy=rdkit.Chem.rdChemDraw.NeedsCleanPolicy.TrustSource [,bool=False [,bool=False]]]]])
    """
def ReactionsFromChemDrawBlock(rxnblock: typing.Any, sanitize: bool = False, removeHs: bool = False) -> typing.Any:
    """
        Extract all reactions from a ChemDraw text block.
        
             Note that the ChemDraw format is large and complex, the RDKit doesn't support
             full functionality, just the base ones required for molecule and
             reaction parsing.
        
             ARGUMENTS:
        
               - filename: the chemdraw filename (.cdx/.cdxml)
        
               - sanitize: if True, sanitize the molecules [default True]
        
               - removeHs: if True, convert explicit Hs into implicit Hs. [default True]
        
             RETURNS:
               a tuple of parsed ChemicalReaction objects.
    
        C++ signature :
            boost::python::api::object ReactionsFromChemDrawBlock(boost::python::api::object [,bool=False [,bool=False]])
    """
def ReactionsFromChemDrawFile(filename: str, sanitize: bool = False, removeHs: bool = False) -> typing.Any:
    """
        Extract all reactions from a ChemDraw file.
        
             Note that the ChemDraw format is large and complex, the RDKit doesn't support
             full functionality, just the base ones required for molecule and
             reaction parsing.
        
             ARGUMENTS:
        
               - filename: the chemdraw filename (.cdx/.cdxml)
        
               - sanitize: if True, sanitize the molecules [default True]
        
               - removeHs: if True, convert explicit Hs into implicit Hs. [default True]
        
             RETURNS:
               a tuple of parsed ChemicalReaction objects.
    
        C++ signature :
            boost::python::api::object ReactionsFromChemDrawFile(char const* [,bool=False [,bool=False]])
    """
