"""
Module containing implementation of SynthonSpace search of Synthon-based chemical libraries such as Enamine REAL.  NOTE: This functionality is experimental and the API and/or results may change in future releases.
"""
from __future__ import annotations
import rdkit.Chem
import typing
__all__: list[str] = ['ConvertTextToDBFile', 'FormattedIntegerString', 'ShapeBuildParams', 'SubstructureResult', 'SynthonSpace', 'SynthonSpaceSearchParams']
class SubstructureResult(Boost.Python.instance):
    """
    Used to return results of SynthonSpace searches.
    """
    @staticmethod
    def GetBestHit(arg1: SubstructureResult) -> rdkit.Chem.Mol:
        """
            Returns the best hit found in the similarity search, even when none were under the search threshold.  May be empty if not a similarity search or nothing came close to a match.
        
            C++ signature :
                boost::shared_ptr<RDKit::ROMol> GetBestHit(RDKit::SynthonSpaceSearch::SearchResults)
        """
    @staticmethod
    def GetCancelled(arg1: SubstructureResult) -> bool:
        """
            Returns whether the search was cancelled or not.
        
            C++ signature :
                bool GetCancelled(RDKit::SynthonSpaceSearch::SearchResults {lvalue})
        """
    @staticmethod
    def GetMaxNumResults(arg1: SubstructureResult) -> int:
        """
            The upper bound on number of results possible.  There may be fewer than this in practice for several reasons such as duplicate reagent sets being removed or the final product not matching the query even though the synthons suggested they would.
        
            C++ signature :
                unsigned long GetMaxNumResults(RDKit::SynthonSpaceSearch::SearchResults {lvalue})
        """
    @staticmethod
    def GetTimedOut(arg1: SubstructureResult) -> bool:
        """
            Returns whether the search timed out or not.
        
            C++ signature :
                bool GetTimedOut(RDKit::SynthonSpaceSearch::SearchResults {lvalue})
        """
    @staticmethod
    def __init__(*args, **kwargs):
        """
        Raises an exception
        This class cannot be instantiated from Python
        """
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    def GetHitMolecules(self) -> list:
        """
            A function returning hits from the search
        
            C++ signature :
                boost::python::list GetHitMolecules(RDKit::SynthonSpaceSearch::SearchResults)
        """
class SynthonSpaceSearchParams(Boost.Python.instance):
    """
    SynthonSpaceSearch parameters.
    """
    __instance_size__: typing.ClassVar[int] = 352
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    @staticmethod
    def __setattr__(arg1: typing.Any, arg2: str, arg3: typing.Any) -> None:
        """
            C++ signature :
                void __setattr__(boost::python::api::object,std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >,boost::python::api::object)
        """
    def __init__(self) -> None:
        """
            C++ signature :
                void __init__(_object*)
        """
    def setUserConformerGenerator(self, func: typing.Any) -> None:
        """
            Allows you to provide a function that will be called instead of the default
             conformer generator to generate conformers for the synthons.  The function should
             take a SMILES string and the maximum number of conformers to generated and
             return a molecule object.
        
            C++ signature :
                void setUserConformerGenerator(RDKit::SynthonSpaceSearch::SynthonSpaceSearchParams {lvalue},boost::python::api::object)
        """
    @property
    def approxSimilarityAdjuster(*args, **kwargs):
        """
        The fingerprint search uses an approximate similarity method before building a product and doing a final check.  The similarityCutoff is reduced by this value for the approximate check.  A lower value will give faster run times at the risk of missing some hits.  The value you use should have a positive correlation with your FOMO.  The default of 0.1 is appropriate for Morgan fingerprints.  With RDKit fingerprints, 0.05 is adequate, and higher than that has been seen to produce long run times.
        """
    @approxSimilarityAdjuster.setter
    def approxSimilarityAdjuster(*args, **kwargs):
        ...
    @property
    def bestHit(*args, **kwargs):
        """
        If True, when doing a shape search it will return the hit conformer with the best shape match to the query conformer.  If False, it just returns the first hit conformer that exceeds the similarity cutoff.  The latter will be faster but the returned hit conformations are likely to be less relevant.
        """
    @bestHit.setter
    def bestHit(*args, **kwargs):
        ...
    @property
    def buildHits(*args, **kwargs):
        """
        If false, reports the maximum number of hits that the search could produce, but doesn't return them.
        """
    @buildHits.setter
    def buildHits(*args, **kwargs):
        ...
    @property
    def confRMSThreshold(*args, **kwargs):
        """
        When doing a shape search, the RMS threshold to use when pruning conformers.  Default=1.0.
        """
    @confRMSThreshold.setter
    def confRMSThreshold(*args, **kwargs):
        ...
    @property
    def enumerateUnspecifiedStereo(*args, **kwargs):
        """
        When doing a shape search, if there is unspecified stereochemistry in either the query or potential hit, enumerate test all possibilities.  Default=False.
        """
    @enumerateUnspecifiedStereo.setter
    def enumerateUnspecifiedStereo(*args, **kwargs):
        ...
    @property
    def excludedVolume(*args, **kwargs):
        """
          Add an excluded volume to use in the shape search.  The volume overlap and mean overlap over clashing atoms will be reported.
        """
    @excludedVolume.setter
    def excludedVolume(*args, **kwargs):
        ...
    @property
    def fragSimilarityAdjuster(*args, **kwargs):
        """
        Similarities of fragments are generally low due to low bit densities.  For the fragment matching, reduce the similarity cutoff off by this amount.  Default=0.1.
        """
    @fragSimilarityAdjuster.setter
    def fragSimilarityAdjuster(*args, **kwargs):
        ...
    @property
    def hitStart(*args, **kwargs):
        """
        The sequence number of the hit to start from.  So that you can return the next N hits of a search having already obtained N-1.  Default=0
        """
    @hitStart.setter
    def hitStart(*args, **kwargs):
        ...
    @property
    def maxExcludedVolume(*args, **kwargs):
        """
        Maximum allowed excluded volume for a hit to be accepted.  Default -1.0 means no maximum.
        """
    @maxExcludedVolume.setter
    def maxExcludedVolume(*args, **kwargs):
        ...
    @property
    def maxHitChiralAtoms(*args, **kwargs):
        """
        Maximum number of chiral atoms in a hit.  Default=-1 means no maximum.
        """
    @maxHitChiralAtoms.setter
    def maxHitChiralAtoms(*args, **kwargs):
        ...
    @property
    def maxHitHeavyAtoms(*args, **kwargs):
        """
        Maximum number of heavy atoms in a hit.  Default=-1 means no maximum.
        """
    @maxHitHeavyAtoms.setter
    def maxHitHeavyAtoms(*args, **kwargs):
        ...
    @property
    def maxHitMolWt(*args, **kwargs):
        """
        Maximum molecular weight for a hit.  Default=0.0 mean no maximum.
        """
    @maxHitMolWt.setter
    def maxHitMolWt(*args, **kwargs):
        ...
    @property
    def maxHits(*args, **kwargs):
        """
        The maximum number of hits to return.  Default=1000.Use -1 for no maximum.
        """
    @maxHits.setter
    def maxHits(*args, **kwargs):
        ...
    @property
    def maxMeanExcludedVolume(*args, **kwargs):
        """
        Maximum mean excluded volume for a hit to be accepted.  The mean is the total excluded volume divided by the number of clashing atoms (within 2 CARBON_RAD of an excluded volume atom).  To try and distinguish between a mild clash over the whole hit and a few atoms having a really bad clash.
        """
    @maxMeanExcludedVolume.setter
    def maxMeanExcludedVolume(*args, **kwargs):
        ...
    @property
    def maxNumFrags(*args, **kwargs):
        """
        The maximum number of fragments the query can be broken into.  Big molecules will create huge numbers of fragments that may cause excessive memory use.  If the number of fragments hits this number, fragmentation stops and the search results will likely be incomplete.  Default=100000.
        """
    @maxNumFrags.setter
    def maxNumFrags(*args, **kwargs):
        ...
    @property
    def maxPossibleHitsToWrite(*args, **kwargs):
        """
        Maximum number of lines to write to possibleHitsFile.  When dealing with huge synthon spaces it's very easy to fill a disk.  Default=10M.
        """
    @maxPossibleHitsToWrite.setter
    def maxPossibleHitsToWrite(*args, **kwargs):
        ...
    @property
    def minHitChiralAtoms(*args, **kwargs):
        """
        Minimum number of chiral atoms in a hit.  Default=0.
        """
    @minHitChiralAtoms.setter
    def minHitChiralAtoms(*args, **kwargs):
        ...
    @property
    def minHitHeavyAtoms(*args, **kwargs):
        """
        Minimum number of heavy atoms in a hit.  Default=0.
        """
    @minHitHeavyAtoms.setter
    def minHitHeavyAtoms(*args, **kwargs):
        ...
    @property
    def minHitMolWt(*args, **kwargs):
        """
        Minimum molecular weight for a hit.  Default=0.0.
        """
    @minHitMolWt.setter
    def minHitMolWt(*args, **kwargs):
        ...
    @property
    def numConformers(*args, **kwargs):
        """
        When doing a shape search, the number of conformers to generate for molecules.  Default=100.
        """
    @numConformers.setter
    def numConformers(*args, **kwargs):
        ...
    @property
    def numThreads(*args, **kwargs):
        """
        The number of threads to use for search.  If > 0, will use that number.  If <= 0, will use the number of hardware threads plus this number.  So if the number of hardware threads is 8, and numThreads is -1, it will use 7 threads.  Default=1.
        """
    @numThreads.setter
    def numThreads(*args, **kwargs):
        ...
    @property
    def possibleHitsFile(*args, **kwargs):
        """
        Name of a file to save the possible hits to. These are the combinations of synthons that might match the query but need building and final checking.  Each line has a space-separated list of the synthons and the hit's name.  The file will be emptied and re-filled if it already exists.
        """
    @possibleHitsFile.setter
    def possibleHitsFile(*args, **kwargs):
        ...
    @property
    def randomSample(*args, **kwargs):
        """
        If True, returns a random sample of the hits, up to maxHits in number.  Default=False.
        """
    @randomSample.setter
    def randomSample(*args, **kwargs):
        ...
    @property
    def randomSeed(*args, **kwargs):
        """
        If using randomSample, this seeds the random number generator so as to give reproducible results.  Default=-1 means use a random seed.
        """
    @randomSeed.setter
    def randomSeed(*args, **kwargs):
        ...
    @property
    def shapeOverlayOptions(*args, **kwargs):
        """
        Options for the shape overlays.
        """
    @shapeOverlayOptions.setter
    def shapeOverlayOptions(*args, **kwargs):
        ...
    @property
    def similarityCutoff(*args, **kwargs):
        """
        Similarity cutoff for returning hits by fingerprint similarity.  At present the fp is hard-coded to be Morgan, bits, radius=2.  Default=0.5.
        """
    @similarityCutoff.setter
    def similarityCutoff(*args, **kwargs):
        ...
    @property
    def stereoEnumOpts(*args, **kwargs):
        """
        Options for stereoisomer enumeration.
        """
    @stereoEnumOpts.setter
    def stereoEnumOpts(*args, **kwargs):
        ...
    @property
    def timeOut(*args, **kwargs):
        """
        Time limit for search, in seconds.  Default is 600s, 0 means no timeout.  Requires an integer
        """
    @timeOut.setter
    def timeOut(*args, **kwargs):
        ...
    @property
    def toTryChunkSize(*args, **kwargs):
        """
        Process possible hits using the given chunk size
        """
    @toTryChunkSize.setter
    def toTryChunkSize(*args, **kwargs):
        ...
    @property
    def useProgressBar(*args, **kwargs):
        """
        Makes a progress bar of given width.  The number given is the number of '*' characters in a full bar.  There will be about another 35 characters or so depending on the size of the job.  Default=0 means no bar.
        """
    @useProgressBar.setter
    def useProgressBar(*args, **kwargs):
        ...
    @property
    def writePossibleHitsAndStop(*args, **kwargs):
        """
        If True, creates the possibleHitsFile and stops without doing the final building and checking.  Default is False.
        """
    @writePossibleHitsAndStop.setter
    def writePossibleHitsAndStop(*args, **kwargs):
        ...
class ShapeBuildParams(Boost.Python.instance):
    """
    Parameters for building shape objects for SynthonSpaceSearch.
    """
    __instance_size__: typing.ClassVar[int] = 168
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    @staticmethod
    def __setattr__(arg1: typing.Any, arg2: str, arg3: typing.Any) -> None:
        """
            C++ signature :
                void __setattr__(boost::python::api::object,std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >,boost::python::api::object)
        """
    def __init__(self) -> None:
        """
            C++ signature :
                void __init__(_object*)
        """
    def setUserConformerGenerator(self, func: typing.Any) -> None:
        """
            Allows you to provide a function that will be called instead of the default
             conformer generator to generate conformers for the synthons.  The function should
             take a SMILES string and the maximum number of conformers to generated and
             return a molecule object.
        
            C++ signature :
                void setUserConformerGenerator(RDKit::SynthonSpaceSearch::ShapeBuildParams {lvalue},boost::python::api::object)
        """
    @property
    def interimFile(*args, **kwargs):
        """
        Interim file to write the SynthonSpace to during shape generation.  In the event of a failure, a restart from this file will be possible.
        """
    @interimFile.setter
    def interimFile(*args, **kwargs):
        ...
    @property
    def interimWrites(*args, **kwargs):
        """
        If an interim file has been given, every this many shapes write a new version of the file.  Default=1000.
        """
    @interimWrites.setter
    def interimWrites(*args, **kwargs):
        ...
    @property
    def maxEmbedAttempts(*args, **kwargs):
        """
        Maximum number of attempts for embedding a single synthon.  Default=10.
        """
    @maxEmbedAttempts.setter
    def maxEmbedAttempts(*args, **kwargs):
        ...
    @property
    def maxSynthonAtoms(*args, **kwargs):
        """
        If >0, sets a maximum number of heavy atoms, excluding dummies, for synthon to have a shape made.  Default=0.
        """
    @maxSynthonAtoms.setter
    def maxSynthonAtoms(*args, **kwargs):
        ...
    @property
    def numConfs(*args, **kwargs):
        """
        Maximum number of conformers per synthon or query.  Default=10
        """
    @numConfs.setter
    def numConfs(*args, **kwargs):
        ...
    @property
    def numThreads(*args, **kwargs):
        """
        The number of threads to use for shape building.  If > 0, will use that number.  If <= 0, will use the number of hardware threads plus this number.Default=1.
        """
    @numThreads.setter
    def numThreads(*args, **kwargs):
        ...
    @property
    def randomSeed(*args, **kwargs):
        """
        Seed for random number generator.  Default=-1 means use system random seed.
        """
    @randomSeed.setter
    def randomSeed(*args, **kwargs):
        ...
    @property
    def rmsThreshold(*args, **kwargs):
        """
        RMS threshold to use when pruning conformations.  Default=1.0.
        """
    @rmsThreshold.setter
    def rmsThreshold(*args, **kwargs):
        ...
    @property
    def shapeSimThreshold(*args, **kwargs):
        """
        When generating shapes, similarity threshold for pruning.  No 2 shapes for each synthon or query will be more similar than this threshold.  Default=1.9.
        """
    @shapeSimThreshold.setter
    def shapeSimThreshold(*args, **kwargs):
        ...
    @property
    def stereoEnumOpts(*args, **kwargs):
        """
        Options for stereoisomer enumeration.
        """
    @stereoEnumOpts.setter
    def stereoEnumOpts(*args, **kwargs):
        ...
    @property
    def timeOut(*args, **kwargs):
        """
        Maximum time in seconds to spend on each synthon when generating conformers.  Default=600 means no timeout.
        """
    @timeOut.setter
    def timeOut(*args, **kwargs):
        ...
    @property
    def useProgressBar(*args, **kwargs):
        """
        Makes a progress bar of given width.  The number given is the number of '*' characters in a full bar.  There will be about another 35 characters or so depending on the size of the job.  Default=0 means no bar.
        """
    @useProgressBar.setter
    def useProgressBar(*args, **kwargs):
        ...
class SynthonSpace(Boost.Python.instance):
    """
    SynthonSpaceSearch object.
    """
    __instance_size__: typing.ClassVar[int] = 224
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    def BuildSynthonFingerprints(self, fingerprintGenerator: typing.Any, progressBarWidth: int = 0) -> None:
        """
            Build the synthon fingerprints ready for similarity searching.  This is done automatically when the first similarity search is done, but if converting a text file to binary format it might need to be done explicitly.  If progressBarWidth is > 0, a progress bar of that width plus about 35 characters is displayed.
        
            C++ signature :
                void BuildSynthonFingerprints(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::FingerprintGenerator<unsigned long> [,unsigned int=0])
        """
    def BuildSynthonShapes(self, py_params: typing.Any = None) -> None:
        """
            Build shapes for the synthons.  The conformations are generated, pruned with the given threshold, which is passed directly to EmbedMultipleConfs.
        
            C++ signature :
                void BuildSynthonShapes(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue} [,boost::python::api::object=None])
        """
    @typing.overload
    def FingerprintSearch(self, query: Mol, fingerprintGenerator: typing.Any, params: typing.Any = None) -> SubstructureResult:
        """
            Does a fingerprint search in the SynthonSpace using the FingerprintGenerator passed in.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults FingerprintSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object [,boost::python::api::object=None])
        """
    @typing.overload
    def FingerprintSearch(self, query: Mol, fingerprintGenerator: typing.Any, params: typing.Any, startLine: int, finishLine: int) -> SubstructureResult:
        """
            Take the contents of params.possibleHitsFile, which is assumed to have been written by an earlier search, and extract those that are indeed hits.  It makes sense that params is the same as the one used to generate the possible hits, but this is not essential.  You could search at a higher similarity threshold than used to create the possible hits, for example. Duplicate SMILES strings produced by different reactions will be returned.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults FingerprintSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object,boost::python::api::object,int,int)
        """
    def FingerprintSearchIncremental(self, query: Mol, fingerprintGenerator: typing.Any, callback: typing.Any, params: typing.Any = None) -> None:
        """
            Does a fingerprint search in the SynthonSpace using the FingerprintGenerator passed in, returning results the callback.
        
            C++ signature :
                void FingerprintSearchIncremental(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object,boost::python::api::object [,boost::python::api::object=None])
        """
    def GetNumProducts(self) -> int:
        """
            Returns number of products in the SynthonSpace, with multiple counting of any duplicates.
        
            C++ signature :
                unsigned long GetNumProducts(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue})
        """
    def GetNumReactions(self) -> int:
        """
            Returns number of reactions in the SynthonSpace.
        
            C++ signature :
                unsigned long GetNumReactions(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue})
        """
    def GetNumSynthons(self) -> int:
        """
            Returns number of synthons in the SynthonSpace.
        
            C++ signature :
                unsigned long GetNumSynthons(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue})
        """
    def GetNumSynthonsWithShapes(self) -> int:
        """
            Returns the number of synthons in the SynthonSpace that have a shape.
        
            C++ signature :
                unsigned long GetNumSynthonsWithShapes(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue})
        """
    def GetSynthonFingerprintType(self) -> str:
        """
            Returns the information string for the fingerprint generator used to create this space.
        
            C++ signature :
                std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > GetSynthonFingerprintType(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue})
        """
    @typing.overload
    def RascalSearch(self, query: Mol, rascalOptions: typing.Any, params: typing.Any = None) -> SubstructureResult:
        """
            Does a search using the Rascal similarity score.  The similarity threshold used is provided by rascalOptions, and the one in params is ignored.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults RascalSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object [,boost::python::api::object=None])
        """
    @typing.overload
    def RascalSearch(self, query: Mol, rascalOptions: typing.Any, params: typing.Any, startLine: int, finishLine: int) -> SubstructureResult:
        """
            Take the contents of params.possibleHitsFile, which is assumed to have been written by an earlier search, and extract those that are indeed hits.  It makes sense that params is the same as the one used to generate the possible hits, but this is not essential.  You could search at a higher similarity threshold than used to create the possible hits, for example. Duplicate SMILES strings produced by different reactions will be returned.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults RascalSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object,boost::python::api::object,int,int)
        """
    def RascalSearchIncremental(self, query: Mol, rascalOptions: typing.Any, callback: typing.Any, params: typing.Any = None) -> None:
        """
            Does a search using the Rascal similarity score.  The similarity threshold used is provided by rascalOptions, and the one in params is ignored.  Returns results iteratively in the callback.
        
            C++ signature :
                void RascalSearchIncremental(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object,boost::python::api::object [,boost::python::api::object=None])
        """
    def ReadDBFile(self, inFile: str, numThreads: int = 1) -> None:
        """
            Reads binary database file.  Takes optional number of threads,default=1.
        
            C++ signature :
                void ReadDBFile(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > [,int=1])
        """
    def ReadTextFile(self, inFile: str) -> None:
        """
            Reads text file of the sort used by ChemSpace/Enamine.
        
            C++ signature :
                void ReadTextFile(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >)
        """
    def ReportSynthonUsage(self) -> None:
        """
            Writes a summary of the synthon usage in the SynthonSpace to stdout.
        
            C++ signature :
                void ReportSynthonUsage(RDKit::SynthonSpaceSearch::SynthonSpace)
        """
    @typing.overload
    def ShapeSearch(self, query: Mol, params: typing.Any = None) -> SubstructureResult:
        """
            Perform a shape similarity search with the given query molecule across the synthonspace library.  Duplicate SMILES strings produced by different reactions will be returned.  Requires a query with at least 1 3D conformer.  Only the first conformer will be used in the search.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults ShapeSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol [,boost::python::api::object=None])
        """
    @typing.overload
    def ShapeSearch(self, query: Mol, params: typing.Any, startLine: int, finishLine: int) -> SubstructureResult:
        """
            Take the contents of params.possibleHitsFile, which is assumed to have been written by an earlier search, and extract those that are indeed hits.  It makes sense that params is the same as the one used to generate the possible hits, but this is not essential.  You could search at a higher similarity threshold than used to create the possible hits, for example. Duplicate SMILES strings produced by different reactions will be returned.  Requires a query with at least 1 3D conformer.  Only the first conformer will be used in the search.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults ShapeSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object,int,int)
        """
    @typing.overload
    def SubstructureSearch(self, query: Mol, substructMatchParams: typing.Any = None, params: typing.Any = None) -> SubstructureResult:
        """
            Does a substructure search in the SynthonSpace.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults SubstructureSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol [,boost::python::api::object=None [,boost::python::api::object=None]])
        """
    @typing.overload
    def SubstructureSearch(self, query: typing.Any, substructMatchParams: typing.Any = None, params: typing.Any = None) -> SubstructureResult:
        """
            Does a substructure search in the SynthonSpace using an extended query.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults SubstructureSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::GeneralizedSubstruct::ExtendedQueryMol [,boost::python::api::object=None [,boost::python::api::object=None]])
        """
    @typing.overload
    def SubstructureSearch(self, query: Mol, substructMatchParams: typing.Any = None, params: typing.Any = None, startLine: int, finishLine: int) -> SubstructureResult:
        """
            Take the contents of params.possibleHitsFile, which is assumed to have been written by an earlier search, and extract those that are indeed hits.  It makes sense that params is the same as the one used to generate the possible hits, but this is not essential.  You could search at a higher similarity threshold than used to create the possible hits, for example.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults SubstructureSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object=None,boost::python::api::object=None,int,int)
        """
    @typing.overload
    def SubstructureSearch(self, query: typing.Any, substructMatchParams: typing.Any = None, params: typing.Any = None, startLine: int, finishLine: int) -> SubstructureResult:
        """
            Take the contents of params.possibleHitsFile, which is assumed to have been written by an earlier search, and extract those that are indeed hits.  It makes sense that params is the same as the one used to generate the possible hits, but this is not essential.  You could search at a higher similarity threshold than used to create the possible hits, for example.
        
            C++ signature :
                RDKit::SynthonSpaceSearch::SearchResults SubstructureSearch(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::GeneralizedSubstruct::ExtendedQueryMol,boost::python::api::object=None,boost::python::api::object=None,int,int)
        """
    def SubstructureSearchIncremental(self, query: Mol, callback: typing.Any, substructMatchParams: typing.Any = None, params: typing.Any = None) -> None:
        """
            Does a substructure search in the SynthonSpace returning results in the callback.
        
            C++ signature :
                void SubstructureSearchIncremental(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},RDKit::ROMol,boost::python::api::object [,boost::python::api::object=None [,boost::python::api::object=None]])
        """
    def Summarise(self) -> None:
        """
            Writes a summary of the SynthonSpace to stdout.
        
            C++ signature :
                void Summarise(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue})
        """
    def WriteDBFile(self, outFile: str) -> None:
        """
            Writes binary database file.
        
            C++ signature :
                void WriteDBFile(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >)
        """
    def WriteEnumeratedFile(self, outFile: str) -> None:
        """
            Writes enumerated library to file.
        
            C++ signature :
                void WriteEnumeratedFile(RDKit::SynthonSpaceSearch::SynthonSpace {lvalue},std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >)
        """
    def __init__(self) -> None:
        """
            C++ signature :
                void __init__(_object*)
        """
def ConvertTextToDBFile(inFilename: str, outFilename: str, fpGen: typing.Any = None, py_shapeParams: typing.Any = None) -> None:
    """
        Convert the text file into the binary DB file in our format.  Assumes that all synthons from a reaction are contiguous in the input file.  This uses a lot less memory than using ReadTextFile() followed by  WriteDBFile().- inFilename the name of the text file- outFilename the name of the binary file- optional fingerprint generator
    
        C++ signature :
            void ConvertTextToDBFile(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >,std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > [,boost::python::api::object=None [,boost::python::api::object=None]])
    """
def FormattedIntegerString(value: int) -> str:
    """
        Format an integer with spaces every 3 digits for ease of reading
    
        C++ signature :
            std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > FormattedIntegerString(long)
    """
