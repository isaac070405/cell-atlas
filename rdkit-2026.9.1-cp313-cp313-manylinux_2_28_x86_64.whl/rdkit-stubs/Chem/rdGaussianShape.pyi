"""
Module containing implementation of Gaussian-based shape overlay and scoring.NOTE: This functionality is experimental and the API and/or results may change in future releases.
"""
from __future__ import annotations
import rdkit.Chem
import typing
__all__: list[str] = ['A_LA_PUBCHEM', 'AlignMol', 'AlignShapes', 'OptimMode', 'ROTATE_0', 'ROTATE_0_FRAGMENT', 'ROTATE_180', 'ROTATE_180_FRAGMENT', 'ROTATE_180_WIGGLE', 'ROTATE_45', 'ROTATE_45_FRAGMENT', 'SHAPE_ONLY', 'SHAPE_PLUS_COLOR', 'SHAPE_PLUS_COLOR_SCORE', 'ScoreMol', 'ScoreMoleculeAllConformers', 'ScoreShape', 'ShapeInput', 'ShapeInputOptions', 'ShapeOverlayOptions', 'StartMode']
class StartMode(Boost.Python.enum):
    A_LA_PUBCHEM: typing.ClassVar[StartMode]
    ROTATE_0: typing.ClassVar[StartMode]
    ROTATE_0_FRAGMENT: typing.ClassVar[StartMode]
    ROTATE_180: typing.ClassVar[StartMode]
    ROTATE_180_FRAGMENT: typing.ClassVar[StartMode]
    ROTATE_180_WIGGLE: typing.ClassVar[StartMode]
    ROTATE_45: typing.ClassVar[StartMode]
    ROTATE_45_FRAGMENT: typing.ClassVar[StartMode]
    __slots__: typing.ClassVar[tuple] = tuple()
    names: typing.ClassVar[dict]
    values: typing.ClassVar[dict]
class OptimMode(Boost.Python.enum):
    SHAPE_ONLY: typing.ClassVar[OptimMode]
    SHAPE_PLUS_COLOR: typing.ClassVar[OptimMode]
    SHAPE_PLUS_COLOR_SCORE: typing.ClassVar[OptimMode]
    __slots__: typing.ClassVar[tuple] = tuple()
    names: typing.ClassVar[dict]
    values: typing.ClassVar[dict]
class ShapeInputOptions(Boost.Python.instance):
    """
    ShapeInputOptions - options for setting up ShapeInput objects.
    """
    __instance_size__: typing.ClassVar[int] = 128
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    @staticmethod
    def __setattr__(arg1: typing.Any, arg2: str, arg3: typing.Any) -> None:
        """
            C++ signature :
                void __setattr__(boost::python::api::object,std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >,boost::python::api::object)
        """
    def __init__(self) -> None:
        """
            C++ signature :
                void __init__(_object*)
        """
    @property
    def allCarbonRadii(*args, **kwargs):
        """
        Whether to use the same radius, appropriate for Carbon, for all atoms.  There is a slight accuracy penalty but significant speed gain if used.  Default=True.
        """
    @allCarbonRadii.setter
    def allCarbonRadii(*args, **kwargs):
        ...
    @property
    def atomRadii(*args, **kwargs):
        """
        Non-standard radii to use for the atoms specified by their indices in the molecule.  Not all atoms need have a radius specified.  A list of tuples of [int, float].
        """
    @atomRadii.setter
    def atomRadii(*args, **kwargs):
        ...
    @property
    def atomSubset(*args, **kwargs):
        """
        If not empty, use just these atoms in the molecule to form the ShapeInput object.
        """
    @atomSubset.setter
    def atomSubset(*args, **kwargs):
        ...
    @property
    def customFeatures(*args, **kwargs):
        """
        Custom features for the shape.  Requires a list of lists of tuples of int (the feature type), Point3D (the coordinates), float (the radius) and optionally a list of indices of the atoms that the feature was derived from.
        """
    @customFeatures.setter
    def customFeatures(*args, **kwargs):
        ...
    @property
    def includeDummies(*args, **kwargs):
        """
        Whether to include dummy atoms in the shape or not.  Default=True.
        """
    @includeDummies.setter
    def includeDummies(*args, **kwargs):
        ...
    @property
    def shapePruneThreshold(*args, **kwargs):
        """
        If there is more than 1 conformer for the input molecule, prune the shapes so that none of them are more similar to each other than the threshold.  Default -1.0 means no pruning.
        """
    @shapePruneThreshold.setter
    def shapePruneThreshold(*args, **kwargs):
        ...
    @property
    def sortShapes(*args, **kwargs):
        """
        If True (the default), the shapes are sorted into descending order of total volume.
        """
    @sortShapes.setter
    def sortShapes(*args, **kwargs):
        ...
    @property
    def useColors(*args, **kwargs):
        """
        Whether to use color features in overlay.  Default=True.
        """
    @useColors.setter
    def useColors(*args, **kwargs):
        ...
class ShapeOverlayOptions(Boost.Python.instance):
    """
    ShapeOverlayOptions - options for controlling the shape overlay process.
    """
    __instance_size__: typing.ClassVar[int] = 80
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    @staticmethod
    def __setattr__(arg1: typing.Any, arg2: str, arg3: typing.Any) -> None:
        """
            C++ signature :
                void __setattr__(boost::python::api::object,std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >,boost::python::api::object)
        """
    def __init__(self) -> None:
        """
            C++ signature :
                void __init__(_object*)
        """
    @property
    def distCutoff(*args, **kwargs):
        """
        If using a distance cutoff, this is the value used.  Default=4.5 of whatever units the coordinates are in.
        """
    @distCutoff.setter
    def distCutoff(*args, **kwargs):
        ...
    @property
    def nSteps(*args, **kwargs):
        """
        Maximum number of steps for the shape overlay process. Default=100.
        """
    @nSteps.setter
    def nSteps(*args, **kwargs):
        ...
    @property
    def normalize(*args, **kwargs):
        """
        Whether to normalize the shapes before overlay by putting them into their canonical orientation (centred on the origin, aligned along its principal axes.  Default=True.
        """
    @normalize.setter
    def normalize(*args, **kwargs):
        ...
    @property
    def optParam(*args, **kwargs):
        """
        If using colors, the relative weights of the shape and color scores, as a fraction of 1.  Default=0.5.
        """
    @optParam.setter
    def optParam(*args, **kwargs):
        ...
    @property
    def optimMode(*args, **kwargs):
        """
        Optimisation mode, controlling what parameters are used to drive the overlay.  Default=SHAPE_PLUS_COLOR_SCORE which optimises using just the overlap of shape, but uses the color to decide which is the best overlay.  Other options are SHAPE_ONLY and SHAPE_AND_COLOR with the latter using the overlap of color features as well. 
        """
    @optimMode.setter
    def optimMode(*args, **kwargs):
        ...
    @property
    def shapeConvergenceCriterion(*args, **kwargs):
        """
        Optimisation stops when the shape Tversky score changes by less than this amount after an optimisation step.  A larger number is faster but gives less precise overlays.  Default=0.001.
        """
    @shapeConvergenceCriterion.setter
    def shapeConvergenceCriterion(*args, **kwargs):
        ...
    @property
    def simAlpha(*args, **kwargs):
        """
        When doing a Tversky similarity, the alpha value.  If alpha and beta are both the default 1.0, it's a Tanimoto similarity.  A high alpha and low beta emphasize the fit volume in the similarity and vice versa. Tversky is O / (A * (R - O) + B * (F - O) + O) where O is the overlap volume, R is the reference's volume and F is the fit's volume.  This is different from that used by OpenEye (O / (A * R + B * F)).
        """
    @simAlpha.setter
    def simAlpha(*args, **kwargs):
        ...
    @property
    def simBeta(*args, **kwargs):
        """
        When doing a Tversky similarity, the beta value.
        """
    @simBeta.setter
    def simBeta(*args, **kwargs):
        ...
    @property
    def startMode(*args, **kwargs):
        """
        Start modes for optimisation.  Default is A_LA_PUBCHEM - as used by the PubChem code - either ROTATE_180_WIGGLE or ROTATE_45 depending on the shape of the two molecules.  ROTATE_180_WIGGLE means 180 rotations about the x, y and z axes, then a small rotation about each axis from that point, using the best scoring one of those. ROTATE_180 uses 180 degree rotations for 4 start points, ROTATE_45 uses 45 degree rotations for 9 start points and ROTATE_0 leaves the relative orientations of the 2 molecules as passed in before optimisation.  There are also ROTATE_0_FRAGMENT, ROTATE_45_FRAGMENT and ROTATE_180_FRAGMENT that as well as the above move the fit molecule to the ends of each of the principal axes and then does the appropriate rotations.  This is useful when the fit molecule is a lot smaller than the reference molecule, but requires a large number of optimisations so is relatively slow.
        """
    @startMode.setter
    def startMode(*args, **kwargs):
        ...
    @property
    def useDistCutoff(*args, **kwargs):
        """
        Whether to use distance cutoff when calculating the shape volumes.  If used, there will be a small penalty in accuracy but a significant increase in speed.  Default=True.
        """
    @useDistCutoff.setter
    def useDistCutoff(*args, **kwargs):
        ...
class ShapeInput(Boost.Python.instance):
    """
    ShapeInput object
    """
    __instance_size__: typing.ClassVar[int] = 360
    @staticmethod
    def NormalizeCoords(arg1: ShapeInput) -> None:
        """
            Align the principal axes to the cartesian axes and centre on the origin. Doesn't require that the shape was created from a molecule.  Creates the necessary transformation if not already done.
        
            C++ signature :
                void NormalizeCoords(RDKit::GaussianShape::ShapeInput {lvalue})
        """
    @staticmethod
    def __reduce__(*args, **kwargs):
        ...
    @staticmethod
    def __setattr__(arg1: typing.Any, arg2: str, arg3: typing.Any) -> None:
        """
            C++ signature :
                void __setattr__(boost::python::api::object,std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >,boost::python::api::object)
        """
    def BestSimilarity(self, fitShape: ShapeInput, threshold: float = -1.0, overlayOpts: typing.Any = None) -> tuple:
        """
            Find the best similarity score between all shapes in this shape and the other one. Stops as soon as it gets something above the threshold. The score runs between 0.0 and 1.0, so the default threshold of -1.0 means no threshold. Fills in the shape numbers of the two that were responsible if there is something above the threshold, and the transformation that did it. Returns a tuple of the similarity scores ((-1.0, -1.0, -1.0) if there was nothing above the threshold), the number of the shape for this object and the shape number of the fitShape that gave the best similarity and the transformation matrix (as a list of 16 floats) that will reproduce the best overlay.  The shapes won't necessarily be left in the state that gave the best similarity.  Note that the shape numbers are not necessarily the same as the original molecule conformation numbers.
        
            C++ signature :
                boost::python::tuple BestSimilarity(RDKit::GaussianShape::ShapeInput {lvalue},RDKit::GaussianShape::ShapeInput [,double=-1.0 [,boost::python::api::object=None]])
        """
    def MaxPossibleSimilarity(self, fitShape: ShapeInput, overlayOpts: typing.Any = None) -> float:
        """
            Get the maximum possible similarity score between all shapes in this shape and all shapes in the fitShape.  The maximum similarity is when one shape is entirely inside the other.  This returns the similarity in that case, which is the upper bound on what is achievable between these 2 shapes.
        
            C++ signature :
                double MaxPossibleSimilarity(RDKit::GaussianShape::ShapeInput {lvalue},RDKit::GaussianShape::ShapeInput {lvalue} [,boost::python::api::object=None])
        """
    def ShapeToMol(self, includeColors: bool = False, withBonds: bool = True) -> rdkit.Chem.Mol:
        """
            Return a molecule with coordinates of the current active shape.  If includeColors is True, (default is False) the color features will be added as xenon atoms.  If withBonds is True (the default) a molecule with bonds will be created, if not then just atoms at the appropriate positions will be produced.
        
            C++ signature :
                RDKit::ROMol* ShapeToMol(RDKit::GaussianShape::ShapeInput {lvalue} [,bool=False [,bool=True]])
        """
    def __init__(self, self: Mol, confId: int, shapeOpt: ShapeInputOptions, overlayOpts: ShapeOverlayOptions) -> None:
        """
            C++ signature :
                void __init__(_object*,RDKit::ROMol,int,RDKit::GaussianShape::ShapeInputOptions,RDKit::GaussianShape::ShapeOverlayOptions)
        """
    @property
    def ColorVolume(*args, **kwargs):
        """
        Get the volume of the shape's color features for the active shap.
        """
    @property
    def GetSmiles(*args, **kwargs):
        """
        Get the SMILES string for the molecule that the shape relates to.
        """
    @property
    def NumAtoms(*args, **kwargs):
        """
        Get the number of atoms defining the shape.
        """
    @property
    def NumFeatures(*args, **kwargs):
        """
        Get the number of features in the shape.
        """
    @property
    def NumShapes(*args, **kwargs):
        """
        Get the number of shapes.  There will be a shape for each conformation of the input molecule, unless shape pruning was carried out in which case there may be fewer.
        """
    @property
    def ShapeVolume(*args, **kwargs):
        """
        Get the volume due to the atoms for the active shape.
        """
    @property
    def getActiveShape(*args, **kwargs):
        """
        Return the number of the active shape.
        """
    @property
    def setActiveShape(*args, **kwargs):
        """
        Set the active shape, the one that will be used for overlays etc.
        """
@typing.overload
def AlignMol(ref: Mol, fit: Mol, refOpts: typing.Any = None, fitOpts: typing.Any = None, overlayOpts: typing.Any = None, refConfId: int = -1, fitConfId: int = -1) -> tuple:
    """
        Aligns a fit molecule onto a reference molecule.  The fit is modified.
        
        Parameters
        ----------
        ref: RDKit.ROMol
            Reference molecule
        fit: RDKit.ROMol
            Fit molecule that will be overlaid
        refOpts: ShapeInputOptions, optional
            Options for building the ref shape
        fitOpts: ShapeInputOptions, optional
            Options for building the fit shape
        overlayOpts: ShapeOverlayOptions, optional
            Options for controlling the overlay
        refConfId : int, optional
            Reference conformer ID (default is -1)
        fitConfId : int, optional
            fit conformer ID (default is -1)
        
        Returns
        -------
        3-tuple of floats
            The results are (combo_score, shape_score, color_score).  The color_score is
            0.0 if color features not used, in which case combo_score and shape_score will
            be the same.
        
    
        C++ signature :
            boost::python::tuple AlignMol(RDKit::ROMol,RDKit::ROMol {lvalue} [,boost::python::api::object=None [,boost::python::api::object=None [,boost::python::api::object=None [,int=-1 [,int=-1]]]]])
    """
@typing.overload
def AlignMol(refShape: ShapeInput, fit: Mol, fitOpts: typing.Any = None, overlayOpts: typing.Any = None, fitConfId: int = -1) -> tuple:
    """
        Aligns a fit molecule onto a reference shape.  The fit is modified.
        
        Parameters
        ----------
        refShape: ShapeInput
            Reference shape
        fit: RDKit.ROMol
            Fit molecule that will be overlaid
        fitOpts: ShapeInputOptions, optional
            Options for building the fit shape
        overlayOpts: ShapeOverlayOptions, optional
            Options for controlling the overlay
        fitConfId : int, optional
            Fit conformer ID (default is -1)
        
        Returns
        -------
        3-tuple of floats
            The results are (combo_score, shape_score, color_score).  The color_score is
            0.0 if color features not used, in which case combo_score and shape_score will
            be the same.
    
        C++ signature :
            boost::python::tuple AlignMol(RDKit::GaussianShape::ShapeInput,RDKit::ROMol {lvalue} [,boost::python::api::object=None [,boost::python::api::object=None [,int=-1]]])
    """
def AlignShapes(refShape: ShapeInput, fitShape: ShapeInput, overlayOpts: typing.Any = None) -> tuple:
    """
        Aligns a fit shape to a reference shape. The fit is modified.
        
        Parameters
        ----------
        refShape : ShapeInput
            Reference shape
        fitShape : ShapeInput
            fit shape
        overlayOpts: ShapeOverlayOptions, optional
            Options for controlling the overlay
        
        
        Returns
        -------
         4-tuple of float, float, list of floats
            The results are (combo_score, shape_score, color_score, matrix)
            The matrix is a 16-float list giving the transformation matrix that
            overlays the fit onto the reference.
    
        C++ signature :
            boost::python::tuple AlignShapes(RDKit::GaussianShape::ShapeInput,RDKit::GaussianShape::ShapeInput {lvalue} [,boost::python::api::object=None])
    """
@typing.overload
def ScoreMol(ref: Mol, fit: Mol, refOpts: typing.Any = None, fitOpts: typing.Any = None, overlayOpts: typing.Any = None, refConfId: int = -1, fitConfId: int = -1) -> tuple:
    """
        Calculates the scores between a reference molecule and a fit
        molecule without overlay.
        
        Parameters
        ----------
        ref: RDKit.ROMol
            Reference molecule
        fit: RDKit.ROMol
            Fit molecule that will be scored
        refOpts: ShapeInputOptions, optional
            Options for building the ref shape
        fitOpts: ShapeInputOptions, optional
            Options for building the fit shape
        overlayOpts: ShapeOverlayOptions, optional
            Options for controlling the volume calculation
        refConfId : int, optional
            Reference conformer ID (default is -1)
        fitConfId : int, optional
            fit conformer ID (default is -1)
        
        Returns
        -------
        3-tuple of floats
            The results are (combo_score, shape_score, color_score).  The color_score is
            0.0 if color features not used, in which case combo_score and shape_score will
            be the same.
        
    
        C++ signature :
            boost::python::tuple ScoreMol(RDKit::ROMol,RDKit::ROMol [,boost::python::api::object=None [,boost::python::api::object=None [,boost::python::api::object=None [,int=-1 [,int=-1]]]]])
    """
@typing.overload
def ScoreMol(refShape: ShapeInput, fit: Mol, fitOpts: typing.Any = None, overlayOpts: typing.Any = None, fitConfId: int = -1) -> tuple:
    """
        Calculates the scores between a reference shape and a fit molecule
        without overlay.
        
        Parameters
        ----------
        refShape: ShapeInput
            Reference shape
        fit: RDKit.ROMol
            Fit molecule that will be scored
        fitOpts: ShapeInputOptions, optional
            Options for building the fit shape
        overlayOpts: ShapeOverlayOptions, optional
            Options for controlling the volume calculation
        fitConfId : int, optional
            fit conformer ID (default is -1)
        
        Returns
        -------
        3-tuple of floats
            The results are (combo_score, shape_score, color_score).  The color_score is
            0.0 if color features not used, in which case combo_score and shape_score will
            be the same.
        
    
        C++ signature :
            boost::python::tuple ScoreMol(RDKit::GaussianShape::ShapeInput,RDKit::ROMol [,boost::python::api::object=None [,boost::python::api::object=None [,int=-1]]])
    """
def ScoreMoleculeAllConformers(ref: Mol, fit: Mol, refOpts: typing.Any = None, fitOpts: typing.Any = None, overlayOpts: typing.Any = None) -> tuple:
    """
        Calculate the scores for the alignment of all conformers
         of the fit molecule onto the reference.  The molecules themselves are not
         altered.
        
        Parameters
        ----------
        ref: RDKit.ROMol
            Reference molecule
        fit: RDKit.ROMol
            Fit molecule that will be scored
        refOpts: ShapeInputOptions, optional
            Options for building the ref shape
        fitOpts: ShapeInputOptions, optional
            Options for building the fit shape
        overlayOpts: ShapeOverlayOptions, optional
            Options for controlling the volume calculation
        
        Returns
        -------
        A complex tuple containing:
            A tuple of tuples containing the scores from aligning the fit conformations
            onto the reference conformations.  scores[0][1] is the score of aligning
            fit conformation 1 onto ref conformation 0.
            The ID of the ref conformer from the best-scoring alignment
            The ID of the fit conformer from the best-scoring alignment
            The transformation that gives the best-scoring alignment for those
            conformers as a 16-float tuple.
        
    
        C++ signature :
            boost::python::tuple ScoreMoleculeAllConformers(RDKit::ROMol,RDKit::ROMol [,boost::python::api::object=None [,boost::python::api::object=None [,boost::python::api::object=None]]])
    """
def ScoreShape(refShape: ShapeInput, fitShape: ShapeInput, overlayOpts: typing.Any = None) -> tuple:
    """
        Calculates the scores between a reference shape and a fit shape without
        overlay.
        
        Parameters
        ----------
        refShape: ShapeInput
            Reference shape
        fitShape: ShapeInput
            Fit shape
        fitOpts: ShapeInputOptions, optional
            Options for building the fit shape
        overlayOpts: ShapeOverlayOptions, optional
            Options for controlling the volume calculation
        
        Returns
        -------
        3-tuple of floats
            The results are (combo_score, shape_score, color_score).  The color_score is
            0.0 if color features not used, in which case combo_score and shape_score will
            be the same.
        
    
        C++ signature :
            boost::python::tuple ScoreShape(RDKit::GaussianShape::ShapeInput,RDKit::GaussianShape::ShapeInput [,boost::python::api::object=None])
    """
A_LA_PUBCHEM: StartMode
ROTATE_0: StartMode
ROTATE_0_FRAGMENT: StartMode
ROTATE_180: StartMode
ROTATE_180_FRAGMENT: StartMode
ROTATE_180_WIGGLE: StartMode
ROTATE_45: StartMode
ROTATE_45_FRAGMENT: StartMode
SHAPE_ONLY: OptimMode
SHAPE_PLUS_COLOR: OptimMode
SHAPE_PLUS_COLOR_SCORE: OptimMode
